import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../core/vpn_provider.dart';
import '../models/server_model.dart';
import '../models/theme_model.dart';

class LatencyModal extends ConsumerStatefulWidget {
  final VpnServer server;
  final int serverIndex;

  const LatencyModal({
    super.key,
    required this.server,
    required this.serverIndex,
  });

  static void show(BuildContext context, VpnServer server, int index) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      useSafeArea: true,
      builder: (ctx) => LatencyModal(server: server, serverIndex: index),
    );
  }

  @override
  ConsumerState<LatencyModal> createState() => _LatencyModalState();
}

class _LatencyModalState extends ConsumerState<LatencyModal> {
  String _selectedUrl = 'https://www.google.com';
  bool _testing = false;
  int? _result;
  bool _failed = false;
  final TextEditingController _customCtrl = TextEditingController();
  bool _customMode = false;

  final List<Map<String, String>> _presets = [
    {'label': 'Google', 'url': 'https://www.google.com'},
    {'label': 'YouTube', 'url': 'https://www.youtube.com'},
    {'label': 'BBC', 'url': 'https://www.bbc.co.uk'},
    {'label': 'Cloudflare', 'url': 'https://1.1.1.1'},
  ];

  @override
  void dispose() {
    _customCtrl.dispose();
    super.dispose();
  }

  Future<void> _test() async {
    setState(() {
      _testing = true;
      _result = null;
      _failed = false;
    });
    final url = _customMode
        ? (_customCtrl.text.isNotEmpty
            ? _customCtrl.text
            : 'https://www.google.com')
        : _selectedUrl;

    final delay = await ref
        .read(vpnProvider.notifier)
        .getServerDelay(widget.server.config, url);

    await ref
        .read(serversProvider.notifier)
        .updateServerPing(widget.serverIndex, delay);

    setState(() {
      _testing = false;
      _result = delay;
      _failed = delay == null;
    });
  }

  @override
  Widget build(BuildContext context) {
    final settings = ref.watch(settingsProvider);
    final theme = settings.theme;
    final primary = theme.primary;

    Color resultColor = Colors.grey;
    String resultLabel = '';
    if (_result != null) {
      if (_result! < 300) {
        resultColor = Colors.green;
        resultLabel = 'Отличная задержка';
      } else if (_result! < 700) {
        resultColor = Colors.yellow;
        resultLabel = 'Нормальная задержка';
      } else {
        resultColor = Colors.red;
        resultLabel = 'Высокая задержка';
      }
    }

    return Container(
      constraints: BoxConstraints(
        maxHeight: MediaQuery.of(context).size.height * 0.85,
      ),
      decoration: BoxDecoration(
        color: theme.background,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
        border: Border.all(color: primary.withOpacity(0.3)),
      ),
      padding: const EdgeInsets.all(20),
      child: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Container(
                width: 40,
                height: 4,
                decoration: BoxDecoration(
                  color: primary.withOpacity(0.5),
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Icon(Icons.speed, color: primary, size: 22),
                const SizedBox(width: 10),
                Text(
                  'Тест задержки',
                  style: TextStyle(
                    color: primary,
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                    fontFamily: theme.fontFamily,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 6),
            Text(
              widget.server.name,
              style: TextStyle(
                color: theme.onBackground.withOpacity(0.7),
                fontSize: 13,
                fontFamily: theme.fontFamily,
              ),
            ),
            const SizedBox(height: 20),
            Text(
              'URL для проверки:',
              style: TextStyle(
                color: primary.withOpacity(0.8),
                fontSize: 12,
                fontFamily: theme.fontFamily,
                letterSpacing: 0.5,
              ),
            ),
            const SizedBox(height: 10),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                for (final p in _presets)
                  GestureDetector(
                    onTap: () => setState(() {
                      _selectedUrl = p['url']!;
                      _customMode = false;
                    }),
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 14, vertical: 7),
                      decoration: BoxDecoration(
                        color: _selectedUrl == p['url'] && !_customMode
                            ? primary.withOpacity(0.2)
                            : Colors.transparent,
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(
                          color: _selectedUrl == p['url'] && !_customMode
                              ? primary
                              : primary.withOpacity(0.3),
                        ),
                      ),
                      child: Text(
                        p['label']!,
                        style: TextStyle(
                          color: _selectedUrl == p['url'] && !_customMode
                              ? primary
                              : theme.onBackground.withOpacity(0.7),
                          fontFamily: theme.fontFamily,
                          fontSize: 13,
                        ),
                      ),
                    ),
                  ),
                GestureDetector(
                  onTap: () => setState(() => _customMode = true),
                  child: Container(
                    padding: const EdgeInsets.symmetric(
                        horizontal: 14, vertical: 7),
                    decoration: BoxDecoration(
                      color: _customMode
                          ? primary.withOpacity(0.2)
                          : Colors.transparent,
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(
                        color: _customMode
                            ? primary
                            : primary.withOpacity(0.3),
                      ),
                    ),
                    child: Text(
                      'Свой URL',
                      style: TextStyle(
                        color: _customMode
                            ? primary
                            : theme.onBackground.withOpacity(0.7),
                        fontFamily: theme.fontFamily,
                        fontSize: 13,
                      ),
                    ),
                  ),
                ),
              ],
            ),
            if (_customMode) ...[
              const SizedBox(height: 10),
              TextField(
                controller: _customCtrl,
                keyboardType: TextInputType.url,
                style: TextStyle(
                    color: theme.onBackground,
                    fontFamily: theme.fontFamily,
                    fontSize: 13),
                decoration: InputDecoration(
                  hintText: 'https://example.com',
                  hintStyle: TextStyle(
                      color: theme.onBackground.withOpacity(0.4),
                      fontFamily: theme.fontFamily),
                  enabledBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                    borderSide:
                        BorderSide(color: primary.withOpacity(0.3)),
                  ),
                  focusedBorder: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(8),
                    borderSide: BorderSide(color: primary),
                  ),
                  contentPadding:
                      const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                  isDense: true,
                ),
              ),
            ],
            const SizedBox(height: 20),
            // Result block
            if (_result != null || _failed) ...[
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: (_failed ? Colors.red : resultColor).withOpacity(0.1),
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(
                      color: (_failed ? Colors.red : resultColor)
                          .withOpacity(0.5)),
                ),
                child: Column(
                  children: [
                    if (_failed) ...[
                      const Icon(Icons.signal_wifi_off, color: Colors.red, size: 36),
                      const SizedBox(height: 8),
                      const Text(
                        'Недоступен',
                        style: TextStyle(
                            color: Colors.red,
                            fontSize: 20,
                            fontWeight: FontWeight.bold),
                      ),
                    ] else ...[
                      Text(
                        '${_result} мс',
                        style: TextStyle(
                          color: resultColor,
                          fontSize: 36,
                          fontWeight: FontWeight.bold,
                          fontFamily: theme.fontFamily,
                        ),
                      ),
                      const SizedBox(height: 4),
                      Text(
                        resultLabel,
                        style: TextStyle(
                            color: resultColor.withOpacity(0.8),
                            fontFamily: theme.fontFamily,
                            fontSize: 13),
                      ),
                    ],
                  ],
                ),
              ),
              const SizedBox(height: 16),
            ],
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: _testing ? null : _test,
                icon: _testing
                    ? SizedBox(
                        width: 18,
                        height: 18,
                        child: CircularProgressIndicator(
                            strokeWidth: 2, color: theme.background),
                      )
                    : const Icon(Icons.speed),
                label: Text(
                    _testing ? 'Тестирование...' : 'Проверить задержку'),
                style: ElevatedButton.styleFrom(
                  backgroundColor: primary,
                  foregroundColor: theme.background,
                  padding: const EdgeInsets.symmetric(vertical: 14),
                  textStyle: TextStyle(
                      fontFamily: theme.fontFamily,
                      fontWeight: FontWeight.bold,
                      fontSize: 15),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
