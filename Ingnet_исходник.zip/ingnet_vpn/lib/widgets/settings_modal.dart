import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../core/vpn_provider.dart';
import '../models/theme_model.dart';

class SettingsModal extends ConsumerStatefulWidget {
  const SettingsModal({super.key});

  static void show(BuildContext context) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      useSafeArea: true,
      builder: (ctx) => const SettingsModal(),
    );
  }

  @override
  ConsumerState<SettingsModal> createState() => _SettingsModalState();
}

class _SettingsModalState extends ConsumerState<SettingsModal> {
  late TextEditingController _intervalCtrl;
  late TextEditingController _timeoutCtrl;
  late TextEditingController _testUrlCtrl;
  bool _customInterval = false;
  bool _customUrl = false;

  final List<String> _urlPresets = [
    'https://www.google.com',
    'https://www.youtube.com',
    'https://www.bbc.co.uk',
  ];

  @override
  void initState() {
    super.initState();
    final s = ref.read(settingsProvider);
    _intervalCtrl = TextEditingController(text: s.autoIntervalMin.toString());
    _timeoutCtrl = TextEditingController(text: s.timeoutMs.toString());
    _testUrlCtrl = TextEditingController(text: s.testUrl);
    _customUrl = !_urlPresets.contains(s.testUrl);
  }

  @override
  void dispose() {
    _intervalCtrl.dispose();
    _timeoutCtrl.dispose();
    _testUrlCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final settings = ref.watch(settingsProvider);
    final sn = ref.read(settingsProvider.notifier);
    final theme = settings.theme;
    final primary = theme.primary;
    final bg = theme.background;
    final maxH = MediaQuery.of(context).size.height;

    return ConstrainedBox(
      constraints: BoxConstraints(maxHeight: maxH * 0.92),
      child: Container(
        decoration: BoxDecoration(
          color: bg,
          borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
          border: Border.all(color: primary.withOpacity(0.3)),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            // Handle bar
            Container(
              margin: const EdgeInsets.only(top: 12, bottom: 4),
              width: 40,
              height: 4,
              decoration: BoxDecoration(
                color: primary.withOpacity(0.5),
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
              child: Row(
                children: [
                  Icon(Icons.settings, color: primary, size: 22),
                  const SizedBox(width: 10),
                  Text(
                    'Настройки',
                    style: TextStyle(
                      color: primary,
                      fontSize: 20,
                      fontWeight: FontWeight.bold,
                      fontFamily: theme.fontFamily,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 8),
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.only(bottom: 32),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    // ─── Auto mode ───────────────────────────────────
                    _section('Авто-переключение', primary, theme, [
                      _switchRow(
                        'Авто-режим',
                        settings.autoMode,
                        (v) => sn.setAutoMode(v),
                        primary,
                        theme,
                      ),
                      if (settings.autoMode) ...[
                        _label('Интервал авто-режима (минуты)', primary, theme),
                        Wrap(
                          spacing: 8,
                          runSpacing: 8,
                          children: [
                            for (final mins in [15, 30, 60])
                              _chip(
                                '$mins мин',
                                settings.autoIntervalMin == mins && !_customInterval,
                                () {
                                  setState(() => _customInterval = false);
                                  sn.setAutoInterval(mins);
                                },
                                primary,
                                theme,
                              ),
                            _chip(
                              'Вручную',
                              _customInterval,
                              () => setState(() => _customInterval = true),
                              primary,
                              theme,
                            ),
                          ],
                        ),
                        if (_customInterval) ...[
                          const SizedBox(height: 8),
                          _textField(
                            _intervalCtrl,
                            'Введите интервал в минутах',
                            primary,
                            theme,
                            keyboardType: TextInputType.number,
                            onChanged: (v) {
                              final n = int.tryParse(v);
                              if (n != null && n > 0) sn.setAutoInterval(n);
                            },
                          ),
                        ],
                        _label('Глубина поиска', primary, theme),
                        for (final depth in [
                          ('FIRST_GOOD', 'Первый рабочий'),
                          ('HALF_LIST', 'Половина списка'),
                          ('FULL_LIST', 'Весь список'),
                        ])
                          RadioListTile<String>(
                            dense: true,
                            value: depth.$1,
                            groupValue: settings.autoDepth,
                            onChanged: (v) => sn.setAutoDepth(v!),
                            title: Text(
                              depth.$2,
                              style: TextStyle(
                                color: theme.onBackground,
                                fontFamily: theme.fontFamily,
                                fontSize: 13,
                              ),
                            ),
                            activeColor: primary,
                            contentPadding: EdgeInsets.zero,
                          ),
                      ],
                    ]),

                    // ─── Timeout ─────────────────────────────────────
                    _section('Таймаут сервера (мс)', primary, theme, [
                      _textField(
                        _timeoutCtrl,
                        'Введите таймаут в миллисекундах',
                        primary,
                        theme,
                        keyboardType: TextInputType.number,
                        onChanged: (v) {
                          final n = int.tryParse(v);
                          if (n != null && n > 0) sn.setTimeoutMs(n);
                        },
                      ),
                    ]),

                    // ─── Test URL ────────────────────────────────────
                    _section('URL для тестирования', primary, theme, [
                      Wrap(
                        spacing: 8,
                        runSpacing: 8,
                        children: [
                          for (final url in _urlPresets)
                            _chip(
                              url.replaceAll('https://', '').split('/').first,
                              settings.testUrl == url && !_customUrl,
                              () {
                                setState(() => _customUrl = false);
                                sn.setTestUrl(url);
                                _testUrlCtrl.text = url;
                              },
                              primary,
                              theme,
                            ),
                          _chip(
                            'Свой URL',
                            _customUrl,
                            () => setState(() => _customUrl = true),
                            primary,
                            theme,
                          ),
                        ],
                      ),
                      if (_customUrl) ...[
                        const SizedBox(height: 8),
                        _textField(
                          _testUrlCtrl,
                          'Введите URL для теста (https://...)',
                          primary,
                          theme,
                          keyboardType: TextInputType.url,
                          onChanged: (v) => sn.setTestUrl(v),
                        ),
                      ],
                    ]),

                    // ─── Notification ─────────────────────────────────
                    _section('Уведомление в шторке', primary, theme, [
                      for (final mode in [
                        ('all', 'Всё (скорость + кнопка)'),
                        ('speed_only', 'Только скорость'),
                        ('button_only', 'Только кнопка'),
                        ('hidden', 'Полностью скрыть'),
                      ])
                        RadioListTile<String>(
                          dense: true,
                          value: mode.$1,
                          groupValue: settings.notificationMode,
                          onChanged: (v) => sn.setNotificationMode(v!),
                          title: Text(
                            mode.$2,
                            style: TextStyle(
                              color: theme.onBackground,
                              fontFamily: theme.fontFamily,
                              fontSize: 13,
                            ),
                          ),
                          activeColor: primary,
                          contentPadding: EdgeInsets.zero,
                        ),
                    ]),

                    // ─── Warnings ──────────────────────────────────────
                    _section('Предупреждения', primary, theme, [
                      _switchRow(
                        'Скрыть предупреждение о РФ (при старте)',
                        settings.suppressStartupWarning,
                        (v) => sn.setSuppressStartupWarning(v),
                        primary,
                        theme,
                      ),
                    ]),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _section(String title, Color primary, AppTheme theme, List<Widget> children) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            title.toUpperCase(),
            style: TextStyle(
              color: primary.withOpacity(0.6),
              fontSize: 11,
              letterSpacing: 1.2,
              fontFamily: theme.fontFamily,
            ),
          ),
          const SizedBox(height: 8),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: theme.surface,
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: primary.withOpacity(0.2)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: children,
            ),
          ),
        ],
      ),
    );
  }

  Widget _switchRow(String label, bool value, Function(bool) onChanged,
      Color primary, AppTheme theme) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Expanded(
          child: Text(
            label,
            style: TextStyle(
              color: theme.onBackground,
              fontFamily: theme.fontFamily,
              fontSize: 14,
            ),
          ),
        ),
        Switch(
          value: value,
          onChanged: onChanged,
          activeColor: primary,
        ),
      ],
    );
  }

  Widget _label(String text, Color primary, AppTheme theme) {
    return Padding(
      padding: const EdgeInsets.only(top: 10, bottom: 6),
      child: Text(
        text,
        style: TextStyle(
          color: primary.withOpacity(0.8),
          fontFamily: theme.fontFamily,
          fontSize: 12,
        ),
      ),
    );
  }

  Widget _chip(String label, bool selected, VoidCallback onTap,
      Color primary, AppTheme theme) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
        decoration: BoxDecoration(
          color: selected ? primary.withOpacity(0.2) : Colors.transparent,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: selected ? primary : primary.withOpacity(0.3),
          ),
        ),
        child: Text(
          label,
          style: TextStyle(
            color: selected ? primary : theme.onBackground.withOpacity(0.7),
            fontFamily: theme.fontFamily,
            fontSize: 12,
          ),
        ),
      ),
    );
  }

  Widget _textField(
    TextEditingController ctrl,
    String hint,
    Color primary,
    AppTheme theme, {
    TextInputType? keyboardType,
    Function(String)? onChanged,
  }) {
    return TextField(
      controller: ctrl,
      keyboardType: keyboardType,
      onChanged: onChanged,
      style: TextStyle(
        color: theme.onBackground,
        fontFamily: theme.fontFamily,
        fontSize: 13,
      ),
      decoration: InputDecoration(
        hintText: hint,
        hintStyle: TextStyle(
          color: theme.onBackground.withOpacity(0.4),
          fontFamily: theme.fontFamily,
          fontSize: 13,
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: BorderSide(color: primary.withOpacity(0.3)),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(8),
          borderSide: BorderSide(color: primary),
        ),
        contentPadding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        isDense: true,
      ),
    );
  }
}
