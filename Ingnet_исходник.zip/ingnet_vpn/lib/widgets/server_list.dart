import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../core/vpn_provider.dart';
import '../models/server_model.dart';
import '../models/theme_model.dart';
import 'latency_modal.dart';

class ServerListWidget extends ConsumerStatefulWidget {
  final AppTheme theme;
  final int selectedIndex;
  final Function(int) onSelect;

  const ServerListWidget({
    super.key,
    required this.theme,
    required this.selectedIndex,
    required this.onSelect,
  });

  @override
  ConsumerState<ServerListWidget> createState() => _ServerListWidgetState();
}

class _ServerListWidgetState extends ConsumerState<ServerListWidget> {
  bool _expanded = false;
  bool _testingAll = false;

  Color _pingColor(int? ping) {
    if (ping == null) return Colors.grey;
    if (ping < 300) return Colors.green;
    if (ping < 700) return Colors.yellow;
    return Colors.red;
  }

  String _pingLabel(int? ping, bool isTesting) {
    if (isTesting) return '...';
    if (ping == null) return '—';
    return '${ping}ms';
  }

  Future<void> _testAll(List<VpnServer> servers) async {
    if (_testingAll) return;
    setState(() => _testingAll = true);

    final serversNotifier = ref.read(serversProvider.notifier);
    final settingsState = ref.read(settingsProvider);
    final vpnNotifier = ref.read(vpnProvider.notifier);

    for (int i = 0; i < servers.length; i++) {
      await serversNotifier.setServerTesting(i, true);
      final delay = await vpnNotifier.getServerDelay(
        servers[i].config,
        settingsState.testUrl,
      );
      await serversNotifier.updateServerPing(i, delay);
      await serversNotifier.setServerTesting(i, false);
    }

    serversNotifier.sortByPing();
    if (mounted) setState(() => _testingAll = false);
  }

  Future<void> _testOne(List<VpnServer> servers, int index) async {
    final serversNotifier = ref.read(serversProvider.notifier);
    final settingsState = ref.read(settingsProvider);
    final vpnNotifier = ref.read(vpnProvider.notifier);

    await serversNotifier.setServerTesting(index, true);
    final delay = await vpnNotifier.getServerDelay(
      servers[index].config,
      settingsState.testUrl,
    );
    await serversNotifier.updateServerPing(index, delay);
    await serversNotifier.setServerTesting(index, false);
  }

  @override
  Widget build(BuildContext context) {
    final servers = ref.watch(serversProvider);
    final primary = widget.theme.primary;
    final surface = widget.theme.surface;

    if (servers.isEmpty) {
      return Container(
        margin: const EdgeInsets.symmetric(horizontal: 16),
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: surface,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: primary.withOpacity(0.3)),
        ),
        child: Center(
          child: Text(
            'Нет серверов. Обновите список.',
            style: TextStyle(
              color: primary.withOpacity(0.6),
              fontFamily: widget.theme.fontFamily,
              fontSize: 13,
            ),
          ),
        ),
      );
    }

    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16),
      decoration: BoxDecoration(
        color: surface,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: primary.withOpacity(0.3)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Header row
          InkWell(
            onTap: () => setState(() => _expanded = !_expanded),
            borderRadius: const BorderRadius.vertical(top: Radius.circular(12)),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              child: Row(
                children: [
                  Icon(Icons.dns, color: primary, size: 20),
                  const SizedBox(width: 8),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Серверы',
                          style: TextStyle(
                            color: primary,
                            fontWeight: FontWeight.bold,
                            fontSize: 14,
                            fontFamily: widget.theme.fontFamily,
                          ),
                        ),
                        Text(
                          servers[widget.selectedIndex.clamp(0, servers.length - 1)].name,
                          style: TextStyle(
                            color: primary.withOpacity(0.7),
                            fontSize: 12,
                            fontFamily: widget.theme.fontFamily,
                          ),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                    ),
                  ),
                  Icon(
                    _expanded ? Icons.keyboard_arrow_up : Icons.keyboard_arrow_down,
                    color: primary,
                  ),
                ],
              ),
            ),
          ),

          if (_expanded) ...[
            Divider(color: primary.withOpacity(0.2), height: 1),
            // Action row
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
              child: Row(
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: _testingAll ? null : () => _testAll(servers),
                      icon: _testingAll
                          ? SizedBox(
                              width: 14,
                              height: 14,
                              child: CircularProgressIndicator(
                                strokeWidth: 2,
                                color: primary,
                              ),
                            )
                          : Icon(Icons.speed, color: primary, size: 16),
                      label: Text(
                        _testingAll ? 'Проверка...' : 'Проверить все',
                        style: TextStyle(
                          color: primary,
                          fontFamily: widget.theme.fontFamily,
                          fontSize: 12,
                        ),
                      ),
                      style: OutlinedButton.styleFrom(
                        side: BorderSide(color: primary.withOpacity(0.5)),
                        padding: const EdgeInsets.symmetric(
                            horizontal: 8, vertical: 6),
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  OutlinedButton.icon(
                    onPressed: () {
                      ref.read(serversProvider.notifier).sortByPing();
                    },
                    icon: Icon(Icons.sort, color: primary, size: 16),
                    label: Text(
                      'Сортировать',
                      style: TextStyle(
                        color: primary,
                        fontFamily: widget.theme.fontFamily,
                        fontSize: 12,
                      ),
                    ),
                    style: OutlinedButton.styleFrom(
                      side: BorderSide(color: primary.withOpacity(0.5)),
                      padding: const EdgeInsets.symmetric(
                          horizontal: 8, vertical: 6),
                    ),
                  ),
                ],
              ),
            ),
            // Server list
            ListView.builder(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              itemCount: servers.length,
              itemBuilder: (ctx, i) {
                final server = servers[i];
                final isSelected = i == widget.selectedIndex;
                final pingColor = _pingColor(server.ping);
                return InkWell(
                  onTap: () {
                    widget.onSelect(i);
                    setState(() => _expanded = false);
                  },
                  child: Container(
                    color: isSelected
                        ? primary.withOpacity(0.08)
                        : Colors.transparent,
                    padding: const EdgeInsets.symmetric(
                        horizontal: 16, vertical: 10),
                    child: Row(
                      children: [
                        Icon(
                          isSelected
                              ? Icons.radio_button_checked
                              : Icons.radio_button_off,
                          color: isSelected ? primary : primary.withOpacity(0.35),
                          size: 16,
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: Text(
                            server.name,
                            style: TextStyle(
                              color: isSelected
                                  ? primary
                                  : widget.theme.onSurface,
                              fontSize: 13,
                              fontFamily: widget.theme.fontFamily,
                              fontWeight: isSelected
                                  ? FontWeight.bold
                                  : FontWeight.normal,
                            ),
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                        const SizedBox(width: 6),
                        // Ping badge — tap to test this server
                        GestureDetector(
                          onTap: () => _testOne(servers, i),
                          child: Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 8, vertical: 4),
                            decoration: BoxDecoration(
                              color: pingColor.withOpacity(0.12),
                              borderRadius: BorderRadius.circular(10),
                              border: Border.all(
                                  color: pingColor.withOpacity(0.5)),
                            ),
                            child: server.isTesting
                                ? SizedBox(
                                    width: 12,
                                    height: 12,
                                    child: CircularProgressIndicator(
                                      strokeWidth: 1.5,
                                      color: primary,
                                    ),
                                  )
                                : Text(
                                    _pingLabel(server.ping, server.isTesting),
                                    style: TextStyle(
                                      color: pingColor,
                                      fontSize: 11,
                                      fontFamily: widget.theme.fontFamily,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                          ),
                        ),
                        const SizedBox(width: 4),
                        // Detailed test modal
                        GestureDetector(
                          onTap: () => LatencyModal.show(context, server, i),
                          child: Icon(
                            Icons.info_outline,
                            color: primary.withOpacity(0.4),
                            size: 16,
                          ),
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ],
        ],
      ),
    );
  }
}
