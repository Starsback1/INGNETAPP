import 'package:flutter/material.dart';
import '../core/vpn_provider.dart';
import '../models/theme_model.dart';

class ConnectButton extends StatefulWidget {
  final VpnStatus status;
  final VoidCallback onPressed;
  final AppTheme theme;

  const ConnectButton({
    super.key,
    required this.status,
    required this.onPressed,
    required this.theme,
  });

  @override
  State<ConnectButton> createState() => _ConnectButtonState();
}

class _ConnectButtonState extends State<ConnectButton>
    with TickerProviderStateMixin {
  late AnimationController _pulseController;
  late AnimationController _spinController;
  late AnimationController _glitchController;

  @override
  void initState() {
    super.initState();
    _pulseController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 1600),
    )..repeat();

    _spinController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 1),
    );

    _glitchController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 200),
    );

    _updateControllers();
  }

  @override
  void didUpdateWidget(ConnectButton oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.status != widget.status ||
        oldWidget.theme.id != widget.theme.id) {
      _updateControllers();
    }
  }

  void _updateControllers() {
    if (widget.status == VpnStatus.connecting) {
      _spinController.repeat();
    } else {
      _spinController.stop();
      _spinController.reset();
    }

    final isConnected = widget.status == VpnStatus.connected;
    if (isConnected && widget.theme.hasGlitch) {
      _glitchController.repeat(
        reverse: true,
        period: const Duration(milliseconds: 4000),
      );
    } else {
      _glitchController.stop();
      _glitchController.reset();
    }
  }

  @override
  void dispose() {
    _pulseController.dispose();
    _spinController.dispose();
    _glitchController.dispose();
    super.dispose();
  }

  Color get _buttonColor {
    switch (widget.status) {
      case VpnStatus.connected:
        return widget.theme.primary;
      case VpnStatus.connecting:
        return widget.theme.primary.withOpacity(0.6);
      case VpnStatus.disconnected:
        return widget.theme.surface;
    }
  }

  String get _label {
    switch (widget.status) {
      case VpnStatus.connected:
        return 'VPN\nАКТИВЕН';
      case VpnStatus.connecting:
        return 'ПОДКЛЮЧЕНИЕ...';
      case VpnStatus.disconnected:
        return 'НАЖМИ\nДЛЯ VPN';
    }
  }

  @override
  Widget build(BuildContext context) {
    final primary = widget.theme.primary;
    final isConnected = widget.status == VpnStatus.connected;
    final isConnecting = widget.status == VpnStatus.connecting;
    final animType = widget.theme.animationType;

    return SizedBox(
      width: 220,
      height: 220,
      child: Stack(
        alignment: Alignment.center,
        children: [
          // Pulse rings
          if (isConnected && animType != 'none') ...[
            _PulseRing(
                controller: _pulseController,
                color: primary,
                delay: 0.0,
                size: 185),
            _PulseRing(
                controller: _pulseController,
                color: primary,
                delay: 0.6,
                size: 185),
          ],
          if (animType == 'wave' && isConnected) ...[
            _PulseRing(
                controller: _pulseController,
                color: primary,
                delay: 0.3,
                size: 205,
                maxScale: 0.3),
          ],

          GestureDetector(
            onTap: widget.onPressed,
            child: AnimatedBuilder(
              animation: _glitchController,
              builder: (context, child) {
                double dx = 0;
                if (widget.theme.hasGlitch && isConnected) {
                  final t = _glitchController.value;
                  dx = t > 0.85 ? ((t - 0.85) / 0.15 - 0.5) * 4 : 0;
                }
                return Transform.translate(
                  offset: Offset(dx, 0),
                  child: child,
                );
              },
              child: AnimatedBuilder(
                animation: _spinController,
                builder: (context, child) {
                  if (isConnecting) {
                    return RotationTransition(
                      turns: _spinController,
                      child: child,
                    );
                  }
                  return child!;
                },
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 300),
                  width: 165,
                  height: 165,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: _buttonColor,
                    border: Border.all(
                      color: primary,
                      width: isConnected ? 3 : 2,
                    ),
                    boxShadow: [
                      BoxShadow(
                        color: primary.withOpacity(isConnected ? 0.5 : 0.2),
                        blurRadius: isConnected ? 28 : 12,
                        spreadRadius: isConnected ? 4 : 1,
                      ),
                    ],
                    gradient: isConnected
                        ? RadialGradient(
                            colors: [
                              primary.withOpacity(0.3),
                              _buttonColor,
                            ],
                          )
                        : null,
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      AnimatedSwitcher(
                        duration: const Duration(milliseconds: 300),
                        child: Icon(
                          isConnecting
                              ? Icons.sync
                              : isConnected
                                  ? Icons.shield
                                  : Icons.power_settings_new,
                          key: ValueKey(widget.status),
                          color: primary,
                          size: 38,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Text(
                        _label,
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: primary,
                          fontWeight: FontWeight.bold,
                          fontSize: isConnecting ? 10 : 12,
                          letterSpacing: 1.5,
                          fontFamily: widget.theme.fontFamily,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _PulseRing extends StatelessWidget {
  final AnimationController controller;
  final Color color;
  final double delay;
  final double size;
  final double maxScale;

  const _PulseRing({
    required this.controller,
    required this.color,
    required this.delay,
    required this.size,
    this.maxScale = 0.6,
  });

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: controller,
      builder: (_, __) {
        final raw = controller.value - delay;
        final t = raw < 0 ? raw + 1.0 : raw;
        final clamped = t.clamp(0.0, 1.0);
        final scale = 1.0 + clamped * maxScale;
        final opacity = (0.3 * (1 - clamped)).clamp(0.0, 0.3);
        return Transform.scale(
          scale: scale,
          child: Container(
            width: size,
            height: size,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(
                color: color.withOpacity(opacity),
                width: 2,
              ),
            ),
          ),
        );
      },
    );
  }
}
