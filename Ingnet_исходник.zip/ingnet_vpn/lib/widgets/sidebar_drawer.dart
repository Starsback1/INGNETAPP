import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:url_launcher/url_launcher.dart';
import '../core/vpn_provider.dart';
import '../models/theme_model.dart';
import 'theme_picker.dart';
import 'settings_modal.dart';

class SidebarDrawer extends ConsumerWidget {
  const SidebarDrawer({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final settings = ref.watch(settingsProvider);
    final theme = settings.theme;
    final primary = theme.primary;
    final surface = theme.surface;
    final bg = theme.background;

    return Drawer(
      backgroundColor: bg,
      child: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: theme.gradient,
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        width: 48,
                        height: 48,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: primary.withOpacity(0.2),
                          border: Border.all(color: primary, width: 2),
                        ),
                        child: Icon(Icons.shield, color: primary, size: 28),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              '⚡ INGNET VPN',
                              style: TextStyle(
                                color: primary,
                                fontSize: 18,
                                fontWeight: FontWeight.bold,
                                fontFamily: theme.fontFamily,
                              ),
                            ),
                            Text(
                              'Безопасный VPN-клиент',
                              style: TextStyle(
                                color: primary.withOpacity(0.7),
                                fontSize: 12,
                                fontFamily: theme.fontFamily,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 14),
                  GestureDetector(
                    onTap: () async {
                      final uri = Uri.parse('https://t.me/INGNET06');
                      if (await canLaunchUrl(uri)) {
                        await launchUrl(uri, mode: LaunchMode.externalApplication);
                      }
                    },
                    child: Row(
                      children: [
                        Icon(Icons.telegram, color: primary, size: 18),
                        const SizedBox(width: 8),
                        Text(
                          'Telegram: @INGNET06',
                          style: TextStyle(
                            color: primary,
                            fontSize: 13,
                            fontFamily: theme.fontFamily,
                            decoration: TextDecoration.underline,
                            decorationColor: primary,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 8),

            _DrawerItem(
              icon: Icons.palette_outlined,
              label: 'Темы',
              theme: theme,
              onTap: () {
                Navigator.pop(context);
                ThemePicker.show(context);
              },
            ),
            _DrawerItem(
              icon: Icons.settings_outlined,
              label: 'Настройки',
              theme: theme,
              onTap: () {
                Navigator.pop(context);
                SettingsModal.show(context);
              },
            ),
            _DrawerItem(
              icon: Icons.refresh_rounded,
              label: 'Обновить серверы',
              theme: theme,
              onTap: () async {
                Navigator.pop(context);
                final serversNotifier = ref.read(serversProvider.notifier);
                ScaffoldMessenger.of(context).showSnackBar(
                  SnackBar(
                    content: Text(
                      'Загрузка серверов...',
                      style: TextStyle(fontFamily: theme.fontFamily),
                    ),
                    backgroundColor: surface,
                    duration: const Duration(seconds: 2),
                  ),
                );
                await serversNotifier.fetchServers();
                if (context.mounted) {
                  final servers = ref.read(serversProvider);
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text(
                        servers.isNotEmpty
                            ? 'Загружено серверов: ${servers.length}'
                            : 'Ошибка загрузки серверов',
                        style: TextStyle(fontFamily: theme.fontFamily),
                      ),
                      backgroundColor: servers.isNotEmpty
                          ? Colors.green.withOpacity(0.8)
                          : Colors.red.withOpacity(0.8),
                    ),
                  );
                }
              },
            ),

            const Divider(height: 1),

            const Spacer(),

            Padding(
              padding: const EdgeInsets.all(16),
              child: Text(
                'v1.0.0 • INGNET',
                style: TextStyle(
                  color: primary.withOpacity(0.4),
                  fontSize: 11,
                  fontFamily: theme.fontFamily,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _DrawerItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final AppTheme theme;
  final VoidCallback onTap;

  const _DrawerItem({
    required this.icon,
    required this.label,
    required this.theme,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final primary = theme.primary;
    return InkWell(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
        child: Row(
          children: [
            Icon(icon, color: primary, size: 22),
            const SizedBox(width: 14),
            Text(
              label,
              style: TextStyle(
                color: theme.onBackground,
                fontSize: 15,
                fontFamily: theme.fontFamily,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
