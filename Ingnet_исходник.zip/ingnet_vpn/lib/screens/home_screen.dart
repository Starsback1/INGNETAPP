import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:url_launcher/url_launcher.dart';
import '../core/vpn_provider.dart';
import '../models/theme_model.dart';
import '../utils/scanlines_painter.dart';
import '../widgets/connect_button.dart';
import '../widgets/server_list.dart';
import '../widgets/sidebar_drawer.dart';
import '../widgets/theme_picker.dart';
import '../widgets/traffic_counter.dart';

class HomeScreen extends ConsumerStatefulWidget {
  const HomeScreen({super.key});

  @override
  ConsumerState<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends ConsumerState<HomeScreen> {
  bool _startupWarnShown = false;
  bool _welcomeShown = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _checkStartupWarning();
    });
  }

  void _checkStartupWarning() {
    final settings = ref.read(settingsProvider);
    if (!settings.suppressStartupWarning && !_startupWarnShown) {
      _startupWarnShown = true;
      _showStartupWarning();
    }
  }

  void _showStartupWarning() {
    final settings = ref.read(settingsProvider);
    final theme = settings.theme;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => AlertDialog(
        backgroundColor: theme.background,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: BorderSide(color: Colors.red.withOpacity(0.8), width: 2.5),
        ),
        title: Row(
          children: [
            const Icon(Icons.warning_amber_rounded, color: Colors.red, size: 30),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                'ВНИМАНИЕ!',
                style: TextStyle(
                  color: Colors.red,
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 2,
                  fontFamily: theme.fontFamily,
                ),
              ),
            ),
          ],
        ),
        content: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                'НАСТОЯТЕЛЬНО ПРОШУ НЕ ЗАПУСКАТЬ ДАННЫЕ АНТИЗАГЛУШКИ В РОССИЙСКИХ СЕРВИСАХ Т.К. УЖЕ ПРОВЕРЕНО ЧТО ЭТИ СЕРВИСЫ БЛОКИРУЮТ РАБОТУ И ПРИВОДЯТ К ПОЛНОЙ НЕРАБОТОСПОСОБНОСТИ',
                style: TextStyle(
                  color: Colors.red,
                  fontSize: 14,
                  fontFamily: theme.fontFamily,
                  height: 1.5,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 12),
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  color: Colors.orange.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: Colors.orange.withOpacity(0.5)),
                ),
                child: Text(
                  'При наличии на телефоне российских приложений (VK, Сбер, Госуслуги, Яндекс и др.) — использовать с осторожностью!',
                  style: TextStyle(
                    color: Colors.orange,
                    fontSize: 13,
                    fontFamily: theme.fontFamily,
                    height: 1.4,
                  ),
                ),
              ),
            ],
          ),
        ),
        actions: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              ElevatedButton(
                onPressed: () => Navigator.pop(ctx),
                style: ElevatedButton.styleFrom(
                  backgroundColor: Colors.red,
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 12),
                ),
                child: Text(
                  'Понял, продолжить',
                  style: TextStyle(
                    fontFamily: theme.fontFamily,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ),
              const SizedBox(height: 8),
              TextButton(
                onPressed: () {
                  ref.read(settingsProvider.notifier).setSuppressStartupWarning(true);
                  Navigator.pop(ctx);
                },
                child: Text(
                  'Больше не показывать',
                  style: TextStyle(
                    color: theme.onBackground.withOpacity(0.5),
                    fontFamily: theme.fontFamily,
                    fontSize: 12,
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  void _showWelcomeDialog() {
    final settings = ref.read(settingsProvider);
    final theme = settings.theme;
    final primary = theme.primary;
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: theme.background,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(20),
          side: BorderSide(color: primary.withOpacity(0.6), width: 2),
        ),
        title: Row(
          children: [
            Icon(Icons.volunteer_activism, color: primary, size: 28),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                'INGNET VPN',
                style: TextStyle(
                  color: primary,
                  fontSize: 20,
                  fontWeight: FontWeight.bold,
                  fontFamily: theme.fontFamily,
                  letterSpacing: 1.5,
                ),
              ),
            ),
          ],
        ),
        content: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                'Ассаламу Аллейкум братья и сестры.',
                style: TextStyle(
                  color: primary,
                  fontWeight: FontWeight.bold,
                  fontSize: 16,
                  fontFamily: theme.fontFamily,
                ),
              ),
              const SizedBox(height: 12),
              Text(
                'Подписывайтесь на телеграм канал. Ваша поддержка поможет мне в продвижении данного проекта и даст больше мотивации для работы. Заранее благодарен всем.',
                style: TextStyle(
                  color: theme.onBackground,
                  fontSize: 14,
                  fontFamily: theme.fontFamily,
                  height: 1.6,
                ),
              ),
              const SizedBox(height: 20),
              GestureDetector(
                onTap: () async {
                  final uri = Uri.parse('https://t.me/INGNET06');
                  if (await canLaunchUrl(uri)) {
                    await launchUrl(uri, mode: LaunchMode.externalApplication);
                  }
                },
                child: Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: primary.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: primary.withOpacity(0.5), width: 1.5),
                  ),
                  child: Row(
                    children: [
                      Icon(Icons.telegram, color: primary, size: 26),
                      const SizedBox(width: 12),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              'Телеграм канал',
                              style: TextStyle(
                                color: primary.withOpacity(0.7),
                                fontSize: 11,
                                fontFamily: theme.fontFamily,
                              ),
                            ),
                            Text(
                              'https://t.me/INGNET06',
                              style: TextStyle(
                                color: primary,
                                fontSize: 14,
                                fontFamily: theme.fontFamily,
                                fontWeight: FontWeight.bold,
                                decoration: TextDecoration.underline,
                                decorationColor: primary,
                              ),
                            ),
                          ],
                        ),
                      ),
                      Icon(Icons.open_in_new, color: primary.withOpacity(0.6), size: 18),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
        actions: [
          Row(
            children: [
              TextButton(
                onPressed: () => Navigator.pop(ctx),
                child: Text(
                  'Отмена',
                  style: TextStyle(
                    color: theme.onBackground.withOpacity(0.5),
                    fontFamily: theme.fontFamily,
                  ),
                ),
              ),
              const Spacer(),
              ElevatedButton.icon(
                onPressed: () async {
                  Navigator.pop(ctx);
                  final uri = Uri.parse('https://t.me/INGNET06');
                  if (await canLaunchUrl(uri)) {
                    await launchUrl(uri, mode: LaunchMode.externalApplication);
                  }
                },
                icon: Icon(Icons.telegram, color: theme.background, size: 18),
                label: Text(
                  'Подписаться',
                  style: TextStyle(
                    fontFamily: theme.fontFamily,
                    color: theme.background,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: primary,
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Future<void> _handleConnect() async {
    final settings = ref.read(settingsProvider);
    final vpnState = ref.read(vpnProvider);
    final vpnNotifier = ref.read(vpnProvider.notifier);
    final servers = ref.read(serversProvider);

    if (vpnState.status == VpnStatus.connected ||
        vpnState.status == VpnStatus.connecting) {
      await vpnNotifier.stopVpn();
      return;
    }

    final hasPermission = await vpnNotifier.requestPermission();
    if (!hasPermission) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Разрешение на VPN не предоставлено')),
        );
      }
      return;
    }

    if (!settings.firstConnectDone && !_welcomeShown) {
      _welcomeShown = true;
      await ref.read(settingsProvider.notifier).markFirstConnectDone();
      if (mounted) _showWelcomeDialog();
    }

    if (servers.isEmpty) return;
    final idx = settings.activeServerIndex.clamp(0, servers.length - 1);
    final server = servers[idx];

    await vpnNotifier.startVpn(
      remark: server.name,
      config: server.config,
      notificationMode: settings.notificationMode,
    );
  }

  @override
  Widget build(BuildContext context) {
    final settings = ref.watch(settingsProvider);
    final vpnState = ref.watch(vpnProvider);
    final theme = settings.theme;
    final primary = theme.primary;
    final bg = theme.background;
    final isMonochrome = theme.id == 'monochrome';

    Widget mainContent = _buildMainContent(theme, primary, vpnState, settings, isMonochrome);

    if (theme.hasScanlines) {
      mainContent = Stack(
        children: [
          mainContent,
          Positioned.fill(
            child: IgnorePointer(
              child: CustomPaint(
                painter: ScanlinesPainter(
                  color: primary.withOpacity(0.03),
                  spacing: 3,
                ),
              ),
            ),
          ),
        ],
      );
    }

    return Theme(
      data: theme.toThemeData(),
      child: Scaffold(
        backgroundColor: bg,
        appBar: _buildAppBar(theme, primary, isMonochrome),
        drawer: const SidebarDrawer(),
        body: mainContent,
        bottomNavigationBar: _buildWarningBar(primary, theme),
      ),
    );
  }

  PreferredSizeWidget _buildAppBar(AppTheme theme, Color primary, bool isMonochrome) {
    return AppBar(
      backgroundColor: theme.background,
      foregroundColor: primary,
      elevation: 0,
      title: Text(
        '⚡ INGNET VPN',
        style: TextStyle(
          color: primary,
          fontWeight: FontWeight.bold,
          fontSize: 18,
          fontFamily: theme.fontFamily,
          letterSpacing: 1.2,
        ),
      ),
      actions: [
        IconButton(
          onPressed: () => ThemePicker.show(context),
          icon: Icon(Icons.palette, color: primary),
          tooltip: 'Темы',
        ),
      ],
    );
  }

  Widget _buildMainContent(
    AppTheme theme,
    Color primary,
    VpnState vpnState,
    SettingsState settings,
    bool isMonochrome,
  ) {
    final servers = ref.watch(serversProvider);

    if (isMonochrome) {
      return _buildMonochromeLayout(theme, primary, vpnState, settings, servers);
    }

    switch (theme.buttonPosition) {
      case 'top':
        return _buildTopLayout(theme, primary, vpnState, settings, servers);
      case 'bottom':
        return _buildBottomLayout(theme, primary, vpnState, settings, servers);
      default:
        return _buildCenterLayout(theme, primary, vpnState, settings, servers);
    }
  }

  Widget _buildCenterLayout(
    AppTheme theme,
    Color primary,
    VpnState vpnState,
    SettingsState settings,
    List servers,
  ) {
    return SingleChildScrollView(
      padding: const EdgeInsets.symmetric(vertical: 16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          const SizedBox(height: 20),
          Center(
            child: ConnectButton(
              status: vpnState.status,
              onPressed: _handleConnect,
              theme: theme,
            ),
          ),
          const SizedBox(height: 24),
          TrafficCounter(
            vpnState: vpnState,
            theme: theme,
            onReset: () => ref.read(vpnProvider.notifier).resetTraffic(),
          ),
          const SizedBox(height: 16),
          if (servers.isNotEmpty)
            ServerListWidget(
              theme: theme,
              selectedIndex: settings.activeServerIndex.clamp(0, servers.length - 1),
              onSelect: (i) => ref.read(settingsProvider.notifier).setActiveServer(i),
            ),
          const SizedBox(height: 80),
        ],
      ),
    );
  }

  Widget _buildTopLayout(
    AppTheme theme,
    Color primary,
    VpnState vpnState,
    SettingsState settings,
    List servers,
  ) {
    return SingleChildScrollView(
      padding: const EdgeInsets.symmetric(vertical: 8),
      child: Column(
        children: [
          const SizedBox(height: 8),
          Center(
            child: ConnectButton(
              status: vpnState.status,
              onPressed: _handleConnect,
              theme: theme,
            ).animate().slideY(
                begin: -0.2, end: 0, duration: 400.ms, curve: Curves.easeOut),
          ),
          const SizedBox(height: 16),
          TrafficCounter(
            vpnState: vpnState,
            theme: theme,
            onReset: () => ref.read(vpnProvider.notifier).resetTraffic(),
          ),
          const SizedBox(height: 12),
          if (servers.isNotEmpty)
            ServerListWidget(
              theme: theme,
              selectedIndex: settings.activeServerIndex.clamp(0, servers.length - 1),
              onSelect: (i) => ref.read(settingsProvider.notifier).setActiveServer(i),
            ),
          const SizedBox(height: 80),
        ],
      ),
    );
  }

  Widget _buildBottomLayout(
    AppTheme theme,
    Color primary,
    VpnState vpnState,
    SettingsState settings,
    List servers,
  ) {
    return Column(
      children: [
        Expanded(
          child: SingleChildScrollView(
            padding: const EdgeInsets.symmetric(vertical: 16),
            child: Column(
              children: [
                TrafficCounter(
                  vpnState: vpnState,
                  theme: theme,
                  onReset: () => ref.read(vpnProvider.notifier).resetTraffic(),
                ),
                const SizedBox(height: 16),
                if (servers.isNotEmpty)
                  ServerListWidget(
                    theme: theme,
                    selectedIndex: settings.activeServerIndex.clamp(0, servers.length - 1),
                    onSelect: (i) => ref.read(settingsProvider.notifier).setActiveServer(i),
                  ),
              ],
            ),
          ),
        ),
        Container(
          padding: const EdgeInsets.only(top: 16, bottom: 24, left: 16, right: 16),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [theme.background.withOpacity(0), theme.background],
              begin: Alignment.topCenter,
              end: Alignment.bottomCenter,
            ),
          ),
          child: Center(
            child: ConnectButton(
              status: vpnState.status,
              onPressed: _handleConnect,
              theme: theme,
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildMonochromeLayout(
    AppTheme theme,
    Color primary,
    VpnState vpnState,
    SettingsState settings,
    List servers,
  ) {
    return SingleChildScrollView(
      padding: const EdgeInsets.all(16),
      child: Column(
        children: [
          const SizedBox(height: 20),
          Center(
            child: ConnectButton(
              status: vpnState.status,
              onPressed: _handleConnect,
              theme: theme,
            ),
          ),
          const SizedBox(height: 24),
          TrafficCounter(
            vpnState: vpnState,
            theme: theme,
            onReset: () => ref.read(vpnProvider.notifier).resetTraffic(),
          ),
          const SizedBox(height: 16),
          if (servers.isNotEmpty)
            ServerListWidget(
              theme: theme,
              selectedIndex: settings.activeServerIndex.clamp(0, servers.length - 1),
              onSelect: (i) => ref.read(settingsProvider.notifier).setActiveServer(i),
            ),
          const SizedBox(height: 16),
          // Settings summary panel (monochrome unique element)
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: theme.surface,
              borderRadius: BorderRadius.circular(4),
              border: Border.all(color: primary.withOpacity(0.4)),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'SETTINGS',
                  style: TextStyle(
                    color: primary.withOpacity(0.5),
                    fontSize: 11,
                    letterSpacing: 3,
                    fontFamily: theme.fontFamily,
                  ),
                ),
                const SizedBox(height: 12),
                _monoRow('Theme', theme.name, primary, theme),
                _monoRow('Timeout', '${settings.timeoutMs}ms', primary, theme),
                _monoRow('Auto mode', settings.autoMode ? 'ON' : 'OFF', primary, theme),
                _monoRow('Test URL', settings.testUrl.replaceAll('https://', ''), primary, theme),
              ],
            ),
          ),
          const SizedBox(height: 80),
        ],
      ),
    );
  }

  Widget _monoRow(String key, String value, Color primary, AppTheme theme) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 5),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            key,
            style: TextStyle(
              color: primary.withOpacity(0.6),
              fontSize: 13,
              fontFamily: theme.fontFamily,
            ),
          ),
          const SizedBox(width: 8),
          Flexible(
            child: Text(
              value,
              textAlign: TextAlign.right,
              style: TextStyle(
                color: primary,
                fontSize: 13,
                fontFamily: theme.fontFamily,
                fontWeight: FontWeight.bold,
              ),
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildWarningBar(Color primary, AppTheme theme) {
    return SafeArea(
      child: Container(
        color: Colors.black,
        padding: const EdgeInsets.symmetric(vertical: 7, horizontal: 8),
        child: Center(
          child: Text(
            '⚠️ НЕ ИСПОЛЬЗОВАТЬ В РОССИЙСКИХ СЕРВИСАХ',
            style: TextStyle(
              color: Colors.red,
              fontWeight: FontWeight.bold,
              fontSize: 11,
              fontFamily: theme.fontFamily,
              letterSpacing: 0.3,
            ),
            textAlign: TextAlign.center,
            overflow: TextOverflow.ellipsis,
            maxLines: 1,
          ),
        ),
      ),
    );
  }
}
