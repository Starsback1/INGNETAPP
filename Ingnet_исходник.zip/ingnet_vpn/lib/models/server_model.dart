class VpnServer {
  final String name;
  final String config;
  int? ping;
  bool isTesting;

  VpnServer({
    required this.name,
    required this.config,
    this.ping,
    this.isTesting = false,
  });

  factory VpnServer.fromJson(Map<String, dynamic> json) {
    return VpnServer(
      name: json['name'] as String,
      config: json['config'] as String,
      ping: json['ping'] as int?,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'name': name,
      'config': config,
      'ping': ping,
    };
  }

  VpnServer copyWith({
    String? name,
    String? config,
    int? ping,
    bool? isTesting,
  }) {
    return VpnServer(
      name: name ?? this.name,
      config: config ?? this.config,
      ping: ping ?? this.ping,
      isTesting: isTesting ?? this.isTesting,
    );
  }
}
